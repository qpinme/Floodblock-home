# FloodBlock Landing (Static v2)
Near 1:1 layout to the lovable.ai mock, built with Tailwind CDN (no build step).
Deploy: push to repo → Settings → Pages → main /(root).